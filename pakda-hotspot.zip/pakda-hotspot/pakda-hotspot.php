<?php
/**
 * Plugin Name: Pakda Hotspot
 * Description: Captura MAC, fuerza MAC en pedido, activa WiFi por RADIUS, autologin y webhook Culqi.
 * Version: 1.0.1
 */

if (!defined('ABSPATH')) exit;
if (!class_exists('WooCommerce')) {
	add_action('admin_notices', function(){
		echo '<div class="notice notice-error"><p><b>Pakda Hotspot:</b> requiere WooCommerce activo.</p></div>';
	});
	return;
}

/**
 * ======================================================
 * Helpers base
 * ======================================================
 */
function pakda_log($msg) { error_log('[PAKDA] ' . $msg); }

function pakda_is_https() {
	return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
}

function pakda_normalizar_mac($mac_raw) {
	$mac = strtoupper(trim((string)$mac_raw));
	$mac = str_replace('-', ':', $mac);
	$mac = preg_replace('/[^0-9A-F:]/', '', $mac);
	if (preg_match('/^[0-9A-F]{12}$/', $mac)) $mac = implode(':', str_split($mac, 2));
	return preg_match('/^([0-9A-F]{2}:){5}[0-9A-F]{2}$/', $mac) ? $mac : '';
}

function pakda_get_mac_from_request() {
	if (!empty($_GET['mac'])) {
		$m = pakda_normalizar_mac($_GET['mac']);
		if ($m) return $m;
	}
	return '';
}

/**
 * ======================================================
 * 0) SESSION: solo front (NO REST/AJAX/admin)
 * ======================================================
 */
add_action('init', function () {
	if (is_admin()) return;
	if (defined('DOING_AJAX') && DOING_AJAX) return;
	if (defined('REST_REQUEST') && REST_REQUEST) return;

	if (!session_id() && !headers_sent()) {
		@session_start();
	}
}, 0);

/**
 * ======================================================
 * Helpers Woo Session
 * ======================================================
 */
function pakda_wc_set_mac($mac) {
	$mac = pakda_normalizar_mac($mac);
	if ($mac && function_exists('WC') && WC()->session) {
		WC()->session->set('pakda_mac', $mac);
	}
}
function pakda_wc_get_mac() {
	if (function_exists('WC') && WC()->session) {
		return pakda_normalizar_mac(WC()->session->get('pakda_mac'));
	}
	return '';
}

/**
 * ======================================================
 * 1) Captura MAC por URL (URL MANDA SIEMPRE)
 * ======================================================
 */
add_action('init', 'pakda_capturar_mac_cookie', 3);
function pakda_capturar_mac_cookie() {
	$mac_url = pakda_get_mac_from_request();
	if (!$mac_url) return;

	$secure = pakda_is_https();
	setcookie('pakda_mac_cookie', $mac_url, time() + 3600, "/", "", $secure, true);
	$_SESSION['pakda_mac_session'] = $mac_url;
	pakda_wc_set_mac($mac_url);

	pakda_log("✅ MAC fijada por URL: $mac_url");
}

/**
 * ======================================================
 * 2) Captura gateway hotspot
 * ======================================================
 */
add_action('init', 'pakda_capturar_gateway_hotspot', 2);
function pakda_capturar_gateway_hotspot() {
	$gw = '';
	if (!empty($_GET['gw'])) $gw = trim((string)$_GET['gw']);
	elseif (!empty($_GET['gateway'])) $gw = trim((string)$_GET['gateway']);
	if (!$gw) return;

	if (preg_match('/^\d{1,3}(\.\d{1,3}){3}$/', $gw)) $gw = 'http://' . $gw . '/login';
	if (preg_match('#^http://\d{1,3}(\.\d{1,3}){3}(:\d+)?$#', $gw)) $gw = rtrim($gw, '/') . '/login';

	$_SESSION['pakda_gw_login'] = $gw;

	$secure = pakda_is_https();
	setcookie('pakda_gw_login', $gw, time() + 3600, "/", "", $secure, true);

	pakda_log("✅ Gateway Hotspot guardado: $gw");
}

/**
 * ======================================================
 * 3) Campo hidden en checkout + validación
 *    (PRIORIDAD: URL > WC/SESSION/COOKIE)
 * ======================================================
 */
add_action('woocommerce_after_order_notes', 'pakda_campo_mac_checkout');
function pakda_campo_mac_checkout($checkout) {
	$mac_value = pakda_get_mac_from_request();

	if (!$mac_value) {
		$wc_mac = pakda_wc_get_mac();
		if ($wc_mac) $mac_value = $wc_mac;
		elseif (!empty($_SESSION['pakda_mac_session'])) $mac_value = pakda_normalizar_mac($_SESSION['pakda_mac_session']);
		elseif (!empty($_COOKIE['pakda_mac_cookie'])) $mac_value = pakda_normalizar_mac($_COOKIE['pakda_mac_cookie']);
	}

	echo '<div id="pakda_mac_wrapper" style="display:none">';
	woocommerce_form_field('pakda_hidden_mac', array(
		'type' => 'hidden',
		'required' => false,
		'default' => $mac_value,
	), $mac_value);
	echo '</div>';

	?>
	<script>
	(function(){
		try{
			var mac = <?php echo json_encode((string)$mac_value); ?> || "";
			mac = (mac || "").toString().trim();
			if(!mac) return;

			var form = document.querySelector("form.checkout");
			if(!form) return;

			var input = form.querySelector('input[name="pakda_hidden_mac"]');
			if(!input){
				input = document.createElement("input");
				input.type = "hidden";
				input.name = "pakda_hidden_mac";
				form.appendChild(input);
			}
			input.value = mac;

			form.addEventListener("submit", function(){
				try{
					var i2 = form.querySelector('input[name="pakda_hidden_mac"]');
					if(i2) i2.value = mac;
				}catch(e){}
			}, true);

		}catch(e){}
	})();
	</script>
	<?php
}

add_action('woocommerce_checkout_process', function () {
	$mac = '';
	if (!empty($_POST['pakda_hidden_mac'])) $mac = pakda_normalizar_mac($_POST['pakda_hidden_mac']);
	if (!$mac) $mac = pakda_get_mac_from_request();
	if (!$mac) $mac = pakda_wc_get_mac();
	if (!$mac && !empty($_SESSION['pakda_mac_session'])) $mac = pakda_normalizar_mac($_SESSION['pakda_mac_session']);
	if (!$mac && !empty($_COOKIE['pakda_mac_cookie'])) $mac = pakda_normalizar_mac($_COOKIE['pakda_mac_cookie']);

	if (!$mac) {
		wc_add_notice('No detectamos tu dispositivo (MAC). Vuelve a abrir el portal desde el WiFi o entra con el link que contiene ?mac=...', 'error');
	}
});

/**
 * ======================================================
 * 4) Forzar MAC en pedido (URL > POST > WC/SESSION/COOKIE)
 * ======================================================
 */
add_action('woocommerce_checkout_create_order', 'pakda_forzar_mac_en_pedido', 20, 2);
function pakda_forzar_mac_en_pedido($order, $data) {
	$actual = pakda_normalizar_mac($order->get_meta('_customer_mac'));
	if ($actual) return;

	$mac = '';
	if (!empty($_POST['pakda_hidden_mac'])) $mac = pakda_normalizar_mac($_POST['pakda_hidden_mac']);
	if (!$mac) $mac = pakda_get_mac_from_request();
	if (!$mac) $mac = pakda_wc_get_mac();
	if (!$mac && !empty($_SESSION['pakda_mac_session'])) $mac = pakda_normalizar_mac($_SESSION['pakda_mac_session']);
	if (!$mac && !empty($_COOKIE['pakda_mac_cookie'])) $mac = pakda_normalizar_mac($_COOKIE['pakda_mac_cookie']);

	if ($mac) {
		$order->update_meta_data('_customer_mac', $mac);
		pakda_log("✅ Forzado _customer_mac en pedido (create_order): $mac");
	} else {
		pakda_log("❌ create_order sin MAC (no se pudo fijar)");
	}
}

add_action('woocommerce_checkout_update_order_meta', function($order_id){
	$mac = '';
	if (!empty($_POST['pakda_hidden_mac'])) $mac = pakda_normalizar_mac($_POST['pakda_hidden_mac']);
	if (!$mac) $mac = pakda_get_mac_from_request();
	if (!$mac) $mac = pakda_wc_get_mac();
	if (!$mac && !empty($_COOKIE['pakda_mac_cookie'])) $mac = pakda_normalizar_mac($_COOKIE['pakda_mac_cookie']);

	if ($mac) update_post_meta($order_id, '_customer_mac', $mac);
}, 10);

/**
 * ======================================================
 * 5) Endpoint autologin (REST)
 * ======================================================
 */
add_action('rest_api_init', function () {
	register_rest_route('pakda/v1', '/autologin', array(
		'methods' => 'GET',
		'callback' => 'pakda_autologin_page',
		'permission_callback' => '__return_true'
	));
});

function pakda_autologin_page($request) {
	global $wpdb;
	nocache_headers();

	$token = !empty($_GET['token']) ? sanitize_text_field($_GET['token']) : '';
	if (!$token) return new WP_REST_Response('No token', 400);

	$order_id = (int)$wpdb->get_var($wpdb->prepare("
		SELECT post_id
		FROM {$wpdb->postmeta}
		WHERE meta_key = '_pakda_autologin_token'
		  AND meta_value = %s
		LIMIT 1
	", $token));

	if (!$order_id) {
		$html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
		<title>Pakda - Reintentando…</title></head>
		<body style="font-family:Arial;background:#0b1220;color:#fff;display:flex;align-items:center;justify-content:center;height:90vh">
		  <div style="text-align:center">
			<h2>⏳ Confirmando pago…</h2>
			<p>Reintentando en 1 segundo…</p>
		  </div>
		  <script>setTimeout(function(){ location.reload(); }, 1000);</script>
		</body></html>';
		return new WP_REST_Response($html, 200, array('Content-Type' => 'text/html; charset=UTF-8'));
	}

	$order = wc_get_order($order_id);
	if (!$order) return new WP_REST_Response('Order not found', 404);

	$mac = pakda_normalizar_mac(get_post_meta($order_id, '_wifi_username', true));
	if (!$mac) $mac = pakda_normalizar_mac($order->get_meta('_customer_mac'));
	if (!$mac) return new WP_REST_Response('Pedido sin MAC', 422);

	$gw_login = '';
	if (!empty($_SESSION['pakda_gw_login'])) $gw_login = trim((string)$_SESSION['pakda_gw_login']);
	elseif (!empty($_COOKIE['pakda_gw_login'])) $gw_login = trim((string)$_COOKIE['pakda_gw_login']);
	if (!$gw_login) $gw_login = 'http://192.168.100.1/login';

	$html = '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Pakda - Conectando…</title></head>
	<body style="font-family:Arial;background:#0b1220;color:#fff;margin:0;display:flex;align-items:center;justify-content:center;height:90vh">
	  <div style="background:#111827;border:1px solid #1f2937;border-radius:14px;padding:24px;max-width:520px;width:92%;text-align:center">
		<div style="font-size:34px">⚙️</div>
		<h2 style="margin:6px 0 8px 0;">Activando tu Internet…</h2>
		<p style="color:#cbd5e1;font-size:13px">Dispositivo: <b>'.esc_html($mac).'</b></p>

		<iframe name="p_if" style="display:none;"></iframe>
		<form id="f" action="'.esc_attr($gw_login).'" method="post" target="p_if">
		  <input type="hidden" name="username" value="'.esc_attr($mac).'">
		  <input type="hidden" name="password" value="'.esc_attr($mac).'">
		  <input type="hidden" name="dst" value="http://www.google.com">
		</form>

		<a href="#" id="btn" style="display:inline-block;margin-top:12px;background:#2563eb;color:#fff;text-decoration:none;padding:12px 18px;border-radius:999px;font-weight:bold">Conectar ahora</a>

		<script>
		  function go(){ try{ document.getElementById("f").submit(); }catch(e){} }
		  setTimeout(go, 250);
		  setTimeout(go, 1200);
		  document.getElementById("btn").addEventListener("click", function(e){ e.preventDefault(); go(); });
		  setTimeout(function(){ try{ window.location.href="http://clients3.google.com/generate_204"; }catch(e){} }, 2500);
		</script>
	  </div>
	</body></html>';

	return new WP_REST_Response($html, 200, array('Content-Type' => 'text/html; charset=UTF-8'));
}

/**
 * ======================================================
 * 6) Webhook Culqi (Basic Auth)
 * ======================================================
 * Recomendado: definir en wp-config.php:
 * define('PAKDA_WEBHOOK_USER','...');
 * define('PAKDA_WEBHOOK_PASS','...');
 */
function pakda_webhook_auth_ok() {
	$user = defined('PAKDA_WEBHOOK_USER') ? (string)PAKDA_WEBHOOK_USER : '';
	$pass = defined('PAKDA_WEBHOOK_PASS') ? (string)PAKDA_WEBHOOK_PASS : '';

	$u = ''; $p = '';
	if (!empty($_SERVER['PHP_AUTH_USER'])) {
		$u = $_SERVER['PHP_AUTH_USER'];
		$p = $_SERVER['PHP_AUTH_PW'] ?? '';
	} elseif (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
		$auth = $_SERVER['HTTP_AUTHORIZATION'];
		if (stripos($auth, 'basic ') === 0) {
			$decoded = base64_decode(substr($auth, 6));
			if ($decoded && strpos($decoded, ':') !== false) list($u, $p) = explode(':', $decoded, 2);
		}
	} elseif (!empty($_SERVER['REDIRECT_HTTP_AUTHORIZATION'])) {
		$auth = $_SERVER['REDIRECT_HTTP_AUTHORIZATION'];
		if (stripos($auth, 'basic ') === 0) {
			$decoded = base64_decode(substr($auth, 6));
			if ($decoded && strpos($decoded, ':') !== false) list($u, $p) = explode(':', $decoded, 2);
		}
	}

	return $user && $pass && hash_equals($user, (string)$u) && hash_equals($pass, (string)$p);
}

add_action('rest_api_init', function () {
	register_rest_route('pakda/v1', '/webhook-culqi', array(
		'methods'  => 'POST',
		'callback' => 'pakda_webhook_culqi',
		'permission_callback' => '__return_true'
	));
});

function pakda_webhook_culqi($request) {
	if (!pakda_webhook_auth_ok()) {
		pakda_log("❌ Webhook Culqi: AUTH FALLÓ");
		return new WP_REST_Response('Unauthorized', 401);
	}

	$raw  = $request->get_body();
	$data = json_decode($raw, true);
	pakda_log("📨 Webhook Culqi recibido: " . substr($raw, 0, 200));

	if (empty($data['type'])) return new WP_REST_Response('No type', 200);

	$eventos_validos = array('charge.capture.succeeded','charge.succeeded','order.payment.succeeded');
	if (!in_array($data['type'], $eventos_validos, true)) return new WP_REST_Response('Event ignored', 200);

	$charge = $data['data'] ?? $data;
	$order_id = 0;

	if (!empty($charge['metadata']['order_id'])) $order_id = (int)$charge['metadata']['order_id'];
	elseif (!empty($charge['reference_code'])) $order_id = (int)preg_replace('/\D/', '', $charge['reference_code']);

	if (!$order_id) return new WP_REST_Response('No order_id', 200);

	$order = wc_get_order($order_id);
	if (!$order) return new WP_REST_Response('Order not found', 200);

	if (!$order->is_paid()) {
		$tx = $charge['id'] ?? ('culqi_' . time());
		$order->payment_complete($tx);
		$order->add_order_note('💳 Pago Culqi confirmado (Webhook) - TX: ' . $tx);
		pakda_log("✅ Pago confirmado por webhook #$order_id");
	}

	return new WP_REST_Response('OK', 200);
}

/**
 * ======================================================
 * 7) Activar WiFi (RADIUS) - hooks
 * ======================================================
 * Recomendado: definir en wp-config.php:
 * define('PAKDA_DB_HOST','...'); define('PAKDA_DB_PORT',3306);
 * define('PAKDA_DB_USER','...'); define('PAKDA_DB_PASS','...'); define('PAKDA_DB_NAME','...');
 */
add_action('woocommerce_payment_complete', 'pakda_activar_wifi', 20, 1);
add_action('woocommerce_order_status_completed', 'pakda_activar_wifi', 20, 1);
add_action('woocommerce_order_status_processing', 'pakda_activar_wifi', 20, 1);

function pakda_activar_wifi($order_id) {
	if (get_post_meta($order_id, '_pakda_wifi_activado', true)) return;

	pakda_log("🚀 pakda_activar_wifi START order_id=$order_id");

	$order = wc_get_order($order_id);
	if (!$order) return;

	$mac = pakda_normalizar_mac($order->get_meta('_customer_mac'));
	if (!$mac) {
		$order->add_order_note('❌ ERROR: Pedido sin MAC. WiFi NO activado.');
		pakda_log("❌ Pedido #$order_id sin _customer_mac");
		return;
	}

	$seconds = 3600;
	foreach ($order->get_items() as $item) {
		$nameItem = strtolower($item->get_name());
		if (strpos($nameItem, '2 horas') !== false) $seconds = 7200;
		if (strpos($nameItem, '24 horas') !== false || strpos($nameItem, '1 día') !== false) $seconds = 86400;
		if (strpos($nameItem, '5 días') !== false) $seconds = 432000;
		if (strpos($nameItem, '7 días') !== false) $seconds = 604800;
		if (strpos($nameItem, '30 días') !== false) $seconds = 2592000;
		break;
	}

	$host = defined('PAKDA_DB_HOST') ? PAKDA_DB_HOST : '';
	$user = defined('PAKDA_DB_USER') ? PAKDA_DB_USER : '';
	$pass = defined('PAKDA_DB_PASS') ? PAKDA_DB_PASS : '';
	$dbnm = defined('PAKDA_DB_NAME') ? PAKDA_DB_NAME : '';
	$port = defined('PAKDA_DB_PORT') ? (int)PAKDA_DB_PORT : 3306;

	if (!$host || !$user || !$pass || !$dbnm) {
		$order->add_order_note('❌ Falta configuración DB PAKDA (wp-config.php).');
		pakda_log("❌ Falta PAKDA_DB_*");
		return;
	}

	$db = mysqli_init();
	mysqli_options($db, MYSQLI_OPT_CONNECT_TIMEOUT, 2);

	if (!@mysqli_real_connect($db, $host, $user, $pass, $dbnm, $port)) {
		$order->add_order_note('❌ Error Conexión VPS: ' . mysqli_connect_error());
		pakda_log("❌ Error conexión DB: " . mysqli_connect_error());
		return;
	}

	pakda_log("✅ DB OK: mac=$mac seconds=$seconds (order_id=$order_id)");

	$stmt = $db->prepare("DELETE FROM radcheck WHERE username = ?");
	$stmt->bind_param("s", $mac); $stmt->execute(); $stmt->close();

	$stmt = $db->prepare("DELETE FROM radreply WHERE username = ?");
	$stmt->bind_param("s", $mac); $stmt->execute(); $stmt->close();

	$stmt = $db->prepare("INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Cleartext-Password', ':=', ?)");
	$stmt->bind_param("ss", $mac, $mac); $stmt->execute(); $stmt->close();

	$stmt = $db->prepare("INSERT INTO radreply (username, attribute, op, value) VALUES (?, 'Mikrotik-Group', ':=', 'full')");
	$stmt->bind_param("s", $mac); $stmt->execute(); $stmt->close();

	$stmt = $db->prepare("INSERT INTO radreply (username, attribute, op, value) VALUES (?, 'Session-Timeout', ':=', ?)");
	$time_str = (string)$seconds;
	$stmt->bind_param("ss", $mac, $time_str); $stmt->execute(); $stmt->close();

	$stmt = $db->prepare("INSERT INTO radreply (username, attribute, op, value) VALUES (?, 'Idle-Timeout', ':=', '1800')");
	$stmt->bind_param("s", $mac); $stmt->execute(); $stmt->close();

	$db->close();

	update_post_meta($order_id, '_pakda_wifi_activado', 'yes');
	update_post_meta($order_id, '_wifi_username', $mac);
	update_post_meta($order_id, '_wifi_time', $seconds);

	$order->add_order_note("✅ WiFi Activado: $mac ($seconds seg)");
}

/**
 * ======================================================
 * 8) THANKYOU: crea token y redirige a autologin
 *    (FUERA de pakda_activar_wifi) ✅
 * ======================================================
 */
add_action('woocommerce_thankyou', 'pakda_thankyou_redirect_autologin', 1);
function pakda_thankyou_redirect_autologin($order_id) {
	if (!$order_id) return;

	$order = wc_get_order($order_id);
	if (!$order) return;

	// Limpia URL para evitar links contaminados (deja solo ?key= si existe)
	echo '<script>
	  (function(){
		try{
		  var u = new URL(window.location.href);
		  var keep = ["key"];
		  var p = new URLSearchParams();
		  keep.forEach(function(k){
			var v = u.searchParams.get(k);
			if(v) p.set(k, v);
		  });
		  var clean = u.origin + u.pathname + (p.toString() ? ("?" + p.toString()) : "");
		  window.history.replaceState({}, document.title, clean);
		}catch(e){}
	  })();
	</script>';

	$mac = pakda_normalizar_mac(get_post_meta($order_id, '_wifi_username', true));
	if (!$mac) $mac = pakda_normalizar_mac($order->get_meta('_customer_mac'));

	if (!$mac) {
		echo '<div style="background:#fee2e2;color:#991b1b;padding:20px;text-align:center;border-radius:10px;margin:20px 0;">
				<h2>⚠️ ALERTA</h2>
				<p>Recibimos tu pago, pero no detectamos tu dispositivo (MAC).</p>
			  </div>';
		return;
	}

	$token = get_post_meta($order_id, '_pakda_autologin_token', true);
	if (!$token) {
		$token = bin2hex(random_bytes(16));
		update_post_meta($order_id, '_pakda_autologin_token', $token);
	}

	$autologin_url = home_url('/wp-json/pakda/v1/autologin?token=' . $token);

	echo '<div style="background:#d1fae5;border:1px solid #34d399;color:#065f46;padding:20px;margin:20px 0;border-radius:12px;text-align:center;">
			<h2 style="margin:0;">🚀 ¡PAGO EXITOSO!</h2>
			<p style="margin:8px 0 0 0;">Conectando tu internet…</p>
		  </div>';

	echo '<script>
		setTimeout(function(){
			window.location.replace("'.esc_js($autologin_url).'");
		}, 500);
	</script>';
}


